import 'package:flutter/material.dart';
import 'package:space_app/app.dart';

void main() {
  runApp(const MyApp());
}
