class Apis {
  static const apiKey = "JhJlwP8YLym7GzI2wkiHhiEmwFv7NGWAI2yh71ES";
  static const photoOfTheDay = "https://api.nasa.gov/planetary/apod?api_key=JhJlwP8YLym7GzI2wkiHhiEmwFv7NGWAI2yh71ES";

}