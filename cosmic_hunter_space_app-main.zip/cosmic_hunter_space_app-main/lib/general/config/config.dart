class AppConfig{

  static const appName = "BMI Calculator";


}