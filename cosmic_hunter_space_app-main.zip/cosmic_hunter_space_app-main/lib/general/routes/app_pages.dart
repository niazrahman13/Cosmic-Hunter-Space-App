class Routes {

  


  // static const loginScreen = '/login-screen';
  // static const signUpScreen = '/sign-up-screen';
  // static const resetPasswordEmail = '/reset-password-with-email';
  // static const resetPasswordPhone = '/reset-password-with-phone';
  // static const otpVerification = '/otp-verification';
  // static const confirmPassword = '/confirm-password';

  // static const allProducts = '/all-prodcut-screen';
  // static const productIn = '/porduct-in-screen';
  // static const allCategoryScreen = '/all-category-screen';
  // static const categoryProductGridview = '/categroy-prodcut-grid-view';
  // static const productDetails = '/product-details-screen';
  // static const productOut = '/product-out-screen';
  // static const reportAndAnalysis = '/report-and-analysis-screen';
  // static const lowStocks = '/low-stocks-screen';
  // static const outOfStocks = '/out-of-stock-screen';
  // static const mostStocks = '/most-stocks-screen';

  // static const allCustomer = '/customers-screen';
  // static const addCustomer = '/add-customer-screen';
  // static const allSupplier = '/suppliers-screen';
  // static const addSupplier = '/add-supplier-screen';
  // static const customerProdileSettings = '/customer-profile-setting';

  // static const salesOrder = '/sales-order-screen';
  // static const purchaseOrder = '/purchase-order-screen';
  // static const productOutSuccessful = '/product-out-successfull';
  // static const productRecit = '/product-recit';
  // static const dashboard = '/dashboard-screen';
}