package com.example.space_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
